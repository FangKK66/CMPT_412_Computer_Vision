load lenet.mat;
layers = get_lenet();
layers{1}.batch_size = 1;

for i = 1:10
    correct_count = 0;
    img = sprintf('../images/test-3.3/%d.jpg', i-1);
    threshold = 140;
    smallObjects = 40;
    realAns = i-1;
    
    
    data = rgb2gray(imread(img));

    data(data > threshold) = 255;
    data(data <= threshold) = 0;

    %Remove small objects from binary image
    data = bwareaopen(data, smallObjects);

    resultsdir = '../results/test-3.3';
    
    image = data;
    image = padarray(image,[10 10], 0 );
    image = imresize(image,[28 28], 'box');

    imageT = transpose(image);
    testImg = reshape(imageT,[],1);
        
    [output, P] = convnet_forward(params, layers, testImg(:,1));
    [~,prediction] = max(P);
    prediction = prediction -1;
        
    [~,~,~] = mkdir(resultsdir);
    name = sprintf('%d_prediction_%d',realAns,prediction);
    filename = [resultsdir sprintf('/%s.jpg', name)];
    imwrite(image, filename); 
end    



