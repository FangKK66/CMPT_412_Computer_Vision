function [output] = inner_product_forward(input, layer, param)

d = size(input.data, 1);
k = size(input.data, 2); % batch size
n = size(param.w, 2); %heigh

w = param.w;
b = param.b;


% Replace the following line with your implementation.
output.data = zeros([n, k]);

w2 = w.';
b2 = b.';
data2 = input.data.';
dataW = data2*w;

for i = 1:n
    for j = 1:k
        output.data(i,j) = dataW(j,i) +b(1,i);
    end
end

output.height = n;
output.width = input.width;
output.channel = input.channel;
output.batch_size = k;

end

