function [output] = relu_forward(input)
output.height = input.height;
output.width = input.width;
output.channel = input.channel;
output.batch_size = input.batch_size;

% Replace the following line with your implementation.
output.data = zeros(size(input.data));
for b = 1:output.batch_size
    output.data(:,b) = max(input.data(:,b),0);
end



%output.data = zeros(size(input.data));
%for b = 1:output.batch_size
%    for c = 1:output.channel
%        for row = 1:output.height
%            for col = 1:output.width
%                output.data(row,col,c,b) = max(input.data(row,col,c,b),0);
%            end
%        end
%    end
%end


end
