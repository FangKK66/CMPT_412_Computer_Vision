addpath('../matlab');

load lenet.mat;
layers = get_lenet();
layers{1}.batch_size = 1;

%real1 = [1,2,3,4,5,6,7,8,9,0];
%real2 = [1,2,3,4,5,6,7,8,9,0];
%real3 = [6,0,6,2,4];

for i = 1:4
    correct_count = 0;
    if i==1
        img = sprintf('../images/image%d.jpg', i);
        threshold = 100;
        smallObjects = 40;
        %realAns = real1;
    elseif i==2
        img = sprintf('../images/image%d.jpg', i);
        threshold = 80;
        smallObjects = 40;
        %realAns = real2;
    elseif i==3
        img = sprintf('../images/image%d.png', i);
        threshold = 100;
        smallObjects = 40;
        %realAns = real3;
    else
        img = sprintf('../images/image%d.jpg', i);
        threshold = 80;
        smallObjects = 40;
        %realAns = real4;
    end
    
    data = rgb2gray(imread(img));

    %Complement image
    data = imcomplement(data);

    data(data > threshold) = 255;
    data(data <= threshold) = 0;

    %Remove small objects from binary image
    data = bwareaopen(data, smallObjects);

    %Measure properties of image regions
    stats = regionprops(data,'BoundingBox');
    

    resultsdir = sprintf('../results/image%d',i);
    %resultsdir = '../results';


    for j = 1:size(stats,1)

        x = stats(j).BoundingBox(1);
        y = stats(j).BoundingBox(2);
        w = stats(j).BoundingBox(3);
        h = stats(j).BoundingBox(4);
        
        x = int32(x);
        y = int32(y);
        w = int32(w);
        h = int32(h);

        image = data(y:y+h,x:x+w);
        image = padarray(image,[10 10], 0 );
        image = imresize(image,[28 28], 'box');
        image = double(image);

        imageT = transpose(image);
        testImg = reshape(imageT,[],1);
        
        [output, P] = convnet_forward(params, layers, testImg(:,1));
        [~,prediction] = max(P);
        prediction = prediction -1;
        
        [~,~,~] = mkdir(resultsdir);
        name = sprintf('%d_prediction_%d',j,prediction);
        filename = [resultsdir sprintf('/%s.jpg', name)];
        imwrite(image, filename);

        %if prediction==realAns(1,j)
        %    correct_count = correct_count + 1;
        %end
        
    end
    
    %msseg = sprintf('image%d Correctness is %d out of %d\n',i,correct_count,size(stats,1));
    %fprintf('%s',msseg);
end


